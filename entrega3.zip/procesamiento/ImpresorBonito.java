package procesamiento;

import asint.SintaxisAbstractaTiny.ProgT;

public interface ImpresorBonito {
	public abstract void procesa(ProgT p); 
}
